package com.miwth.and102_asm.adapter;

public interface ChangeCategoryCallback {
    void changeCategory(int categoryID);
}
